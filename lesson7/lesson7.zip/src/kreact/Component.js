function Component(props) {
  this.props = props;
}

Component.prototype.isReactComponent = {};

export default Component;
