import { ApplyPluginsType } from '/Users/gaoshaoyun/workspace/kkb-react/lesson6-now/node_modules/@umijs/runtime';
import { plugin } from './plugin';

const routes = [
  {
    "path": "/",
    "component": require('/Users/gaoshaoyun/workspace/kkb-react/lesson6-now/src/.umi/plugin-layout/Layout.tsx').default,
    "routes": [
      {
        "path": "/",
        "component": require('@/pages/index').default,
        "exact": true
      },
      {
        "path": "/login",
        "component": require('@/pages/login/index').default,
        "exact": true
      },
      {
        "path": "/more",
        "component": require('@/pages/more/index').default,
        "wrappers": [require('@/wrappers/auth/').default],
        "exact": true
      },
      {
        "path": "/channel",
        "component": require('@/pages/channel/index').default,
        "wrappers": [require('@/wrappers/auth/').default],
        "exact": true
      },
      {
        "path": "/about",
        "component": require('@/pages/about').default,
        "exact": true
      }
    ]
  }
];

// allow user to extend routes
plugin.applyPlugins({
  key: 'patchRoutes',
  type: ApplyPluginsType.event,
  args: { routes },
});

export { routes };
