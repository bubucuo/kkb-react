
export { connect, useDispatch, useStore, useSelector } from '/Users/gaoshaoyun/workspace/kkb-react/lesson6-now/node_modules/dva';
export { getApp as getDvaApp } from './dva';
